#include "i2c.h"

/* * External handle for I2C1 defined in main.c
 */
extern I2C_HandleTypeDef hi2c1;

/* * Change this to 0x4E if 0x27 is your 7-bit address
 * (Address << 1)
 */
#define LCD_ADDR 0x4E

/**
 * @brief Send command to LCD via I2C
 */
void lcd_send_cmd(char cmd) {
  char data_u, data_l;
  uint8_t data_t[4];

  data_u = (cmd & 0xf0);
  data_l = ((cmd << 4) & 0xf0);

  /* Bit masking for PCF8574: Backlight=1, En=1/0, RW=0, RS=0 */
  data_t[0] = data_u | 0x0C;  // en=1, rs=0
  data_t[1] = data_u | 0x08;  // en=0, rs=0
  data_t[2] = data_l | 0x0C;  // en=1, rs=0
  data_t[3] = data_l | 0x08;  // en=0, rs=0

  HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, (uint8_t *)data_t, 4, 100);
}

/**
 * @brief Send data to LCD via I2C
 */
void lcd_send_data(char data) {
  char data_u, data_l;
  uint8_t data_t[4];

  data_u = (data & 0xf0);
  data_l = ((data << 4) & 0xf0);

  /* Bit masking for PCF8574: Backlight=1, En=1/0, RW=0, RS=1 */
  data_t[0] = data_u | 0x0D;  // en=1, rs=1
  data_t[1] = data_u | 0x09;  // en=0, rs=1
  data_t[2] = data_l | 0x0D;  // en=1, rs=1
  data_t[3] = data_l | 0x09;  // en=0, rs=1

  HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, (uint8_t *)data_t, 4, 100);
}

/**
 * @brief Initialize LCD in 4-bit mode
 */
void lcd_init(void) {
  // Wait for LCD to power up
  HAL_Delay(50);
  lcd_send_cmd(0x33); // Initialize
  lcd_send_cmd(0x32); // Set to 4-bit mode
  HAL_Delay(5);

  lcd_send_cmd(0x28); // 2 line, 5x8 Matrix
  HAL_Delay(1);
  lcd_send_cmd(0x0C); // Display on, cursor off
  HAL_Delay(1);
  lcd_send_cmd(0x06); // Increment cursor
  HAL_Delay(1);
  lcd_send_cmd(0x01); // Clear display
  HAL_Delay(2);
}

/**
 * @brief Set cursor position
 */
void lcd_put_cur(int row, int col) {
  switch (row) {
    case 0:
      col |= 0x80;
      break;
    case 1:
      col |= 0xC0;
      break;
  }
  lcd_send_cmd(col);
}

/**
 * @brief Send string to LCD
 */
void lcd_send_string(char *str) {
  while (*str) lcd_send_data(*str++);
}

/**
 * @brief Clear LCD screen
 */
void lcd_clear(void) {
  lcd_send_cmd(0x01);
  HAL_Delay(2);
}
